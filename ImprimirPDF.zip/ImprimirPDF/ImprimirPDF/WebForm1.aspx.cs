﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ImprimirPDF
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void btnGerarPDF_Click(object sender, EventArgs e)
        {
            string strPath = @"C:\Users\Wodson Luiz\Downloads" + "\\" + "Etq1.pdf";

            //if (File.Exists(strPath))
            //    File.Delete(strPath);
            //#region Gerar PDF
           


            //using (MemoryStream ms = new MemoryStream())
            //{
            //    System.IO.FileStream fs = new FileStream(strPath, FileMode.Create);
            //    Document document = new Document(PageSize.A4, 25, 25, 30, 30);
            //    PdfWriter writer = PdfWriter.GetInstance(document, fs);

            //    document.Open();

            //    BaseFont f_cb = BaseFont.CreateFont(@"C:\Windows\Fonts\Arial.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            //    BaseFont f_cn = BaseFont.CreateFont(@"C:\Windows\Fonts\Arial.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

            //    #region Empresa
            //    PdfContentByte cbEmpresa = writer.DirectContent;
            //    cbEmpresa.BeginText();
            //    //Tamanho da fonte
            //    cbEmpresa.SetFontAndSize(f_cn, 12);
            //    //posicionamento
            //    cbEmpresa.SetTextMatrix(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text)); // Left, Top
            //    cbEmpresa.ShowText("Hospital Municipal de Santo André");
            //    cbEmpresa.EndText();
            //    cbEmpresa.Stroke();
            //    #endregion 

            //    #region Paciente
            //    PdfContentByte cbPaciente = writer.DirectContent;
            //    cbPaciente.BeginText();
            //    //Tamanho da fonte
            //    cbPaciente.SetFontAndSize(f_cn, 9);
            //    //posicionamento
            //    cbPaciente.SetTextMatrix(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text) - 15); // Left, Top
            //    cbPaciente.ShowText("Wodson Luiz Correia Feitosa");
            //    cbPaciente.EndText();
            //    cbPaciente.Stroke();
            //    #endregion 

            //    #region Local
            //    PdfContentByte cbLocal = writer.DirectContent;
            //    cbLocal.BeginText();
            //    //Tamanho da fonte
            //    cbLocal.SetFontAndSize(f_cn, 9);
            //    //posicionamento
            //    cbLocal.SetTextMatrix(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text) - 30); // Left, Top
            //    cbLocal.ShowText("PRONTO SOCORRO");
            //    cbLocal.EndText();
            //    cbLocal.Stroke();
            //    #endregion 

            //    //cbEmpresa.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "This text is left aligned", 200, 800, 0);
            //    //cbEmpresa.ShowTextAligned(PdfContentByte.ALIGN_RIGHT, "This text is right aligned", 200, 788, 0);

            //    //cbEmpresa.Rectangle(400, 700, 100, 100);
               
            //    document.Close();
            //    writer.Close();
            //}
            //#endregion

            #region Imprimir

            StreamWriter arquivo = new StreamWriter(strPath);

            try
            {
               
                try
                {

                    System.Drawing.Printing.PrintDocument docToPrint = new System.Drawing.Printing.PrintDocument();
                    docToPrint.PrinterSettings.PrinterName = "1º Andar - HP Color LaserJet CP1510 Series PCL 6 em srv-0006";
                    docToPrint.DocumentName = strPath;
                    

                    if (docToPrint.PrinterSettings.IsValid)
                    {
                        docToPrint.Print();
                    }

                    else
                    {

                    }

                }

                catch (Exception ex)
                {

                }
            }

            catch (Exception ex)
            {

            }

            //ProcessStartInfo info = new ProcessStartInfo();
            //info.Verb = "print";
            //info.FileName = @"C:\Users\Wodson Luiz\Downloads\Etq1.pdf";
            //info.CreateNoWindow = true;
            //info.WindowStyle = ProcessWindowStyle.Hidden;
            //Process p = new Process();
            //p.StartInfo = info;
            //p.Start();
            //p.WaitForInputIdle();
            //System.Threading.Thread.Sleep(3000);
            //if (false == p.CloseMainWindow())
            //    p.Kill();
            #endregion
        }
    }
}