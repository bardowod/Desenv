﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BuscarCep
{
    public partial class Cep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {

            HttpWebRequest requisicao = (HttpWebRequest)WebRequest.Create("http://www.buscacep.correios.com.br/servicos/dnec/consultaLogradouroAction.do?Metodo=listaLogradouro&CEP=" + txtCEP.Text + "&TipoConsulta=cep");
            HttpWebResponse resposta = (HttpWebResponse)requisicao.GetResponse();

            int cont;
            byte[] buffer = new byte[1000];
            StringBuilder sb = new StringBuilder();
            string temp;

            Stream stream = resposta.GetResponseStream();

            do
            {
                cont = stream.Read(buffer, 0, buffer.Length);
                temp = Encoding.Default.GetString(buffer, 0, cont).Trim();
                sb.Append(temp);

            } while (cont > 0);

            string pagina = sb.ToString();

            if (pagina.IndexOf("<font color=\"black\">CEP NAO ENCONTRADO</font>") >= 0)
            {
                litResultado.Text = "<b style=\"color:red\">CEP não localizado.</b>";
            }
            else
            {

                string cep = string.Empty;
                string tipoLogradouro = string.Empty;
                tipoLogradouro = string.Empty;

                string tlg = string.Empty;
                string logradouro = string.Empty;
                string bairro = string.Empty;
                string cidade = string.Empty;
                string estado = string.Empty;
                string resultado = string.Empty;

                cep = txtCEP.Text.Trim().Replace("-", "");
                tipoLogradouro = Regex.Match(pagina, "<td width=\"268\" style=\"padding: 2px\">(.*)</td>").Groups[1].Value;
                tipoLogradouro = tipoLogradouro.Substring(0, tipoLogradouro.IndexOf(" "));

                tlg = Regex.Match(pagina, "<td width=\"268\" style=\"padding: 2px\">(.*)</td>").Groups[1].Value;
                logradouro = Regex.Match(pagina, "<td width=\"268\" style=\"padding: 2px\">(.*)</td>").Groups[1].Value;
                bairro = Regex.Matches(pagina, "<td width=\"140\" style=\"padding: 2px\">(.*)</td>")[0].Groups[1].Value;
                cidade = Regex.Matches(pagina, "<td width=\"140\" style=\"padding: 2px\">(.*)</td>")[1].Groups[1].Value;
                estado = Regex.Match(pagina, "<td width=\"25\" style=\"padding: 2px\">(.*)</td>").Groups[1].Value;
                resultado = String.Format("Logradouro: {0} <br/> Bairro: {1} <br/> Cidade: {2} <br/> Estado: {3}", logradouro, bairro, cidade, estado);
                litResultado.Text = resultado;
            }
        }
    }
}