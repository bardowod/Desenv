﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Management;

namespace WMI
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CriarTabela();
        }

        protected void CriarTabela()
        {
            SelectQuery selectQuery = new SelectQuery("Win32_LogicalDisk");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(selectQuery);
            string strTeste = string.Empty;
            foreach (ManagementObject disk in searcher.Get())
            {
                strTeste += '|' + disk.ToString() ;
            }

            if (!string.IsNullOrEmpty(strTeste))
                lblTeste.Text = strTeste;
        }
    }
}