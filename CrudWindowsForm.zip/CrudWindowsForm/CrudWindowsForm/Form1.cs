﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CrudWindowsForm
{
    public partial class fnCadastroCliente : Form
    {
        string connectionString = @"Data Source=WODSON\MSSQLSERVER2;Initial Catalog=CrudDesenv;Integrated Security=True";
        bool novo;

        public fnCadastroCliente()
        {
            InitializeComponent();

            txtNome.Enabled = false;
            txtEndereco.Enabled = false;
            txtCep.Enabled = false;
            txtBairro.Enabled = false;
            txtCidade.Enabled = false;
            txtUF.Enabled = false;
            txtTelefone.Enabled = false;
            novo = false;
        }

        private void fnCadastroCliente_Load(object sender, EventArgs e)
        {
            
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtNome.Enabled = true;
            txtEndereco.Enabled = true;
            txtCep.Enabled = true;
            txtBairro.Enabled = true;
            txtCidade.Enabled = true;
            txtUF.Enabled = true;
            txtTelefone.Enabled = true;
            novo = true;
        }

        protected void Limpar()
        {
            txtNome.Text = string.Empty;
            txtEndereco.Text = string.Empty;
            txtCep.Text = string.Empty;
            txtBairro.Text = string.Empty;
            txtCidade.Text = string.Empty;
            txtUF.Text = string.Empty;
            txtTelefone.Text = string.Empty;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            string sql = "";
            if (novo)
            {
                sql = "INSERT INTO CLIENTE (NOME,ENDERECO,CEP,BAIRRO,CIDADE,UF,TELEFONE) " +
                            "VALUES ('" + txtNome.Text + "', '" + txtEndereco.Text + "', '" + txtCep.Text + "', '" + txtBairro.Text + "', '" + txtCidade.Text + "', '" + txtUF.Text + "', '" + txtTelefone.Text + "')";
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.Text;
                con.Open();

                try
                {
                    int i = cmd.ExecuteNonQuery();

                    if (i > 0)
                    {
                        Limpar();
                        MessageBox.Show("Cadastro realizado com Sucesso!");
                    }
                        
                }
                catch (Exception ex)
                {

                    throw new Exception("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                }

            }
            else
            {
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.Text;
                con.Open();

                try
                {
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                        MessageBox.Show("Cadastro realizado com Sucesso!");
                }
                catch (Exception ex)
                {

                    throw new Exception("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            
            
        }
    }
}
